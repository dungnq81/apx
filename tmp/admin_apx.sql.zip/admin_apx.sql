-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 28, 2019 at 11:37 PM
-- Server version: 5.5.60-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_apx`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('0b7d4179a9bb30012e9e625bd06d5a61694a11b2', '27.75.141.51', 1564239941, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343233393934313b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343233393431353b),
('43341e8e05bb87dc1171dc153433fe050601a9d5', '171.233.107.109', 1564299067, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343239393036373b6c616e675f636f64657c733a323a227669223b61646d696e5f72656469726563747c733a31353a2261646d696e2f70616765732f616464223b),
('434ec1a43147753b2f1bb00941ab992de43de3b5', '171.233.107.109', 1564301715, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343330313731343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343239393036373b),
('5e5e6163e3b865064e6d22c4679d99fa55e4887c', '27.75.141.51', 1564242744, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343234323734343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343233393431353b737563636573737c733a33313a225468c3aa6d207472616e67206de1bb9b69207468c3a06e682063c3b46e672e223b5f5f63695f766172737c613a313a7b733a373a2273756363657373223b733a333a226f6c64223b7d),
('83203f4ab3da000a36de73f82d20eff7a0bb0a87', '27.75.141.51', 1564242745, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343234323734343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343233393431353b),
('8606c66ff0fbf6382912075605d2aa8a18a1775a', '27.75.141.51', 1564217491, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343231373434323b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343231373439313b),
('8fed2c07b9bfcf93b98a5f9fc5e66cb1a7267981', '27.75.141.51', 1564227877, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343232373837363b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343232353332383b),
('a901c04e91f584604ec4932467322fa1ed8b302e', '27.75.141.51', 1564227876, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343232373837363b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343232353332383b),
('abcf91b0ef868ac169b651a38efa9e02f363978c', '171.233.107.109', 1564301714, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343330313731343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343239393036373b),
('b3a2c4a9d5e57749f7c70a21dba7e87630c89d9d', '171.233.107.109', 1564329903, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343332393639343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343332373339353b737563636573737c733a33313a225468c3aa6d207472616e67206de1bb9b69207468c3a06e682063c3b46e672e223b5f5f63695f766172737c613a313a7b733a373a2273756363657373223b733a333a226f6c64223b7d),
('bc434d298aefb3c319063c1879cfc6afe3e0ca4b', '171.233.107.109', 1564329694, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343332393639343b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343332373339353b),
('c32bb5a5e496f2dbea099e692f450a8a764b0742', '171.233.107.109', 1564328155, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536343332383135353b6c616e675f636f64657c733a323a227669223b757365725f69647c733a313a2231223b757365725f6c6f67696e5f74696d657c693a313536343332373339353b);

-- --------------------------------------------------------

--
-- Table structure for table `entities`
--

CREATE TABLE `entities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `alias` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'table name',
  `controller` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pos` bigint(20) NOT NULL DEFAULT '0',
  `css` text COLLATE utf8mb4_unicode_ci,
  `js` text COLLATE utf8mb4_unicode_ci,
  `img` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_social` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_on` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `updated_on` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `published_on` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `restricted_key` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restricted_password` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_noindex` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `meta_nofollow` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `meta_noarchive` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `css_class_wrap` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'html class wrapper content.',
  `title_copy` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `entities`
--

INSERT INTO `entities` (`id`, `alias`, `controller`, `pos`, `css`, `js`, `img`, `img_social`, `created_on`, `updated_on`, `published_on`, `restricted_key`, `restricted_password`, `meta_noindex`, `meta_nofollow`, `meta_noarchive`, `css_class_wrap`, `title_copy`) VALUES
(2, 'pages', 'pages', 0, '\\2E page\\2D wrap\\20 \\7B \\D \\A \\20 position\\3A \\20 relative\\3B \\D \\A \\7D \\D \\A ', NULL, NULL, NULL, 1564329902, 0, 1564329660, 'def000001bbda5a8f3be3b1da5a15bf190e598c1a6c4e038fe3eeec99450d48e44907cc023d94854f91b6f4e351226c1745591f196d72aaad4370c92c390597feb2d6097', 'def502004666bb98afff759ad7453a53d49ed2f5fe07426b03c1744ea6dcdefff412bb794e39937c543dfcd4bfba1b95cd31fecf95c3fd51889ae129265d3a583dff9d33807b24db23e28b29ca0eac79aad8fcff816a2154d1e9', 0, 0, 1, 'page-wrap', 'Một đoạn dịch của H. Rackham năm 1914');

-- --------------------------------------------------------

--
-- Table structure for table `entities_recycles`
--

CREATE TABLE `entities_recycles` (
  `id` int(10) UNSIGNED NOT NULL,
  `entities_id` bigint(20) UNSIGNED NOT NULL,
  `languages_id` smallint(5) UNSIGNED DEFAULT NULL,
  `created_on` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `languages_supports_id` smallint(5) UNSIGNED NOT NULL,
  `pos` smallint(6) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `languages_supports_id`, `pos`, `is_default`) VALUES
(1, 1, 0, 0),
(2, 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `languages_supports`
--

CREATE TABLE `languages_supports` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` text COLLATE utf8mb4_unicode_ci,
  `direction` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'ltr'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages_supports`
--

INSERT INTO `languages_supports` (`id`, `name`, `folder`, `code`, `locale`, `flag`, `direction`) VALUES
(1, 'English', 'en', 'en', 'en_US', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHzSURBVHjaYkxOP8IAB//+Mfz7w8Dwi4HhP5CcJb/n/7evb16/APL/gRFQDiAAw3JuAgAIBEDQ/iswEERjGzBQLEru97ll0g0+3HvqMn1SpqlqGsZMsZsIe0SICA5gt5a/AGIEarCPtFh+6N/ffwxA9OvP/7//QYwff/6fZahmePeB4dNHhi+fGb59Y4zyvHHmCEAAAW3YDzQYaJJ93a+vX79aVf58//69fvEPlpIfnz59+vDhw7t37968efP3b/SXL59OnjwIEEAsDP+YgY53b2b89++/awvLn98MDi2cVxl+/vl6mituCtBghi9f/v/48e/XL86krj9XzwEEEENy8g6gu22rfn78+NGs5Ofr16+ZC58+fvyYwX8rxOxXr169fPny+fPn1//93bJlBUAAsQADZMEBxj9/GBxb2P/9+S/R8u3vzxuyaX8ZHv3j8/YGms3w8ycQARmi2eE37t4ACCDGR4/uSkrKAS35B3TT////wADOgLOBIaXIyjBlwxKAAGKRXjCB0SOEaeu+/y9fMnz4AHQxCP348R/o+l+//sMZQBNLEvif3AcIIMZbty7Ly6t9ZmXl+fXj/38GoHH/UcGfP79//BBiYHjy9+8/oUkNAAHEwt1V/vI/KBY/QSISFqM/GBg+MzB8A6PfYC5EFiDAABqgW776MP0rAAAAAElFTkSuQmCC', 'ltr'),
(2, 'Tiếng Việt', 'vi', 'vi', 'vi_VN', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAALCAIAAAD5gJpuAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAFsSURBVHjaYvzPgAD/UNlYEUAAmuTYAAAQhAEYqF/zFbe50RZ1cMmS9TLi0pJLRjZohAMTGFUN9HdnHgEE1sDw//+Tp0ClINW/f4NI9d////3+f+b3/1+////+9f/XL6A4o6ws0AaAAGIBm/0fRTVQ2v3Pf97f/4/9Aqv+DdHA8Ps3UANAALEAMSNQNdDGP3+ALvnf8vv/t9//9X/////7f+uv/4K//iciNABNBwggsJP+/IW4kuH3n//1v/8v+wVSDURmv/57//7/CeokoKFA0wECiAnkpL9/wH4CO+DNr/+VQA1A9PN/w6//j36CVIMRxEkAAQR20m+QpSBXgU0CuSTj9/93v/8v//V/xW+48UBD/zAwAAQQSAMzOMiABoBUswCd8ev/M7A669//OX7///Lr/x+gBlCoAJ0DEEAgDUy//zBISoKNAfoepJNRFmQkyJecfxj4/kDCEIiAigECiPErakTiiWMIAAgwAB4ZUlqMMhQQAAAAAElFTkSuQmCC', 'ltr');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `pid` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_label` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages_id` smallint(5) UNSIGNED DEFAULT NULL,
  `entities_id` bigint(20) UNSIGNED NOT NULL,
  `pages_layouts_id` smallint(5) UNSIGNED NOT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8mb4_unicode_ci,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','live','hide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `comment_enabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `rss_enabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `meta_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_append_name` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `canonical_url` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_url` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `pid`, `title`, `slug`, `title_label`, `languages_id`, `entities_id`, `pages_layouts_id`, `ip_address`, `uri`, `short`, `content`, `status`, `comment_enabled`, `rss_enabled`, `meta_title`, `meta_description`, `meta_append_name`, `canonical_url`, `redirect_url`) VALUES
(2, NULL, 'Một đoạn dịch của H. Rackham năm 1914', 'mot-doan-dich-cua-h-rackham-nam-1914', NULL, 2, 2, 1, '171.233.107.109', 'mot-doan-dich-cua-h-rackham-nam-1914', 'On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue.', '<h3>Đoạn Lorem Ipsum chuẩn, được sử dụng từ những năm 1500</h3>\r\n<p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.”</p>\r\n<h3>Đoạn 1.10.32 trong “De Finibus Bonorum et Malorum” viết bởi Cicero năm 45 trước Công Nguyên</h3>\r\n<p>“Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?”</p>\r\n<h3>Một đoạn dịch của H. Rackham năm 1914</h3>\r\n<p>“But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?”</p>\r\n<h3>Đoạn 1.10.33 trong “De Finibus Bonorum et Malorum” viết bởi Cicero năm 45 trước Công Nguyên</h3>\r\n<p>“At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.”</p>\r\n<h3>Một đoạn dịch của H. Rackham năm 1914</h3>\r\n<p>“On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.”</p>', 'draft', 1, 1, 'Một đoạn dịch của H. Rackham năm 1914', 'Một đoạn dịch của H. Rackham năm 1914', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages_layouts`
--

CREATE TABLE `pages_layouts` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci COMMENT 'Json format',
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'name of layout',
  `pos` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages_layouts`
--

INSERT INTO `pages_layouts` (`id`, `title`, `slug`, `pos`) VALUES
(1, '{\"vi\":\"Giao diện mặc định\",\"en\":\"Default layout\"}', '', 1),
(2, '{\"vi\":\"Liên hệ\",\"en\":\"Contact layout\"}', 'contact', 0),
(3, '{\"vi\":\"Có sidebar\",\"en\":\"Sidebar layout\"}', 'sidebar', 0);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `users_groups_id` smallint(5) UNSIGNED NOT NULL,
  `controller` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `redirects`
--

CREATE TABLE `redirects` (
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `default` text COLLATE utf8mb4_unicode_ci,
  `value` text COLLATE utf8mb4_unicode_ci,
  `pos` smallint(6) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `slug`, `description`, `default`, `value`, `pos`, `options`) VALUES
(1, 'Default Theme', 'default_theme', 'Select the theme you want users to see by default.', NULL, 'default', 0, NULL),
(2, 'Admin Theme', 'admin_theme', 'Admin theme', NULL, 'cms', 0, NULL),
(3, 'Default Languages', 'default_language', 'Admin default language', 'vi', 'vi', 0, NULL),
(4, 'Site Name', 'site_name', 'Site name', NULL, 'APX CMS', 0, NULL),
(5, 'Recaptcha SiteKey', 'recaptcha_sitekey', 'Recaptcha SiteKey', NULL, '6Le83pAUAAAAAL8Y8F9tA9ZcwiTAfzJBgRcxINJI', 0, NULL),
(6, 'Recaptcha SecretKey', 'recaptcha_secretkey', 'Recaptcha SecretKey', NULL, '6Le83pAUAAAAADIogjW2Uh7mUDJK_oQHSIkNRtnh', 0, NULL),
(7, 'Date Format', 'date_format', 'Date Format', NULL, 'Y-m-d H:i:s', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_password` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','lock') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `private_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'For encrypt and decrypt data',
  `verified_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_on` int(10) UNSIGNED DEFAULT NULL,
  `updated_on` int(10) UNSIGNED DEFAULT NULL,
  `users_groups_id` smallint(5) UNSIGNED DEFAULT NULL,
  `forgotten_code` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forgotten_code_time` int(10) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activation_code` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_pass_change_time` int(10) UNSIGNED DEFAULT NULL,
  `last_login_time` int(10) UNSIGNED DEFAULT NULL,
  `verified_password` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci COMMENT 'Json profile'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `phone`, `password`, `old_password`, `status`, `private_key`, `verified_phone`, `ip_address`, `created_on`, `updated_on`, `users_groups_id`, `forgotten_code`, `forgotten_code_time`, `remember_code`, `activation_code`, `last_pass_change_time`, `last_login_time`, `verified_password`, `data`) VALUES
(1, 'apx_admin', NULL, NULL, 'JGFyZ29uMmlkJHY9MTkkbT0xMDI0LHQ9MixwPTIkUVhORVZrRlRkMU5DVUZsYU1IZEZiZyR2MVRHNFJadTloUFdZeEtLQTFpSy9Td1BjcDh4TC8yQnJ1Ynp6R0lXRGhZ', NULL, 'active', 'def0000060c683d96a4e5a5bcec9d29d446c50925c9f190dfdb04a39bc3429dd3f2c5251f8b655341d39868c3df4b567bd308b8be324bd075b1b88c4cd0e4a1b3baa5709', NULL, '27.75.141.51', 1564217442, NULL, 2, NULL, NULL, 'c5df9578939dafa4513c32f409b052200ca47eab97ab21fe858e6e5ab740f2f5', NULL, NULL, 1564327395, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `not_deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `not_deleted`, `name`, `description`) VALUES
(1, 0, 'member', 'Member Group'),
(2, 1, 'administrator', 'Administrator Group');

-- --------------------------------------------------------

--
-- Table structure for table `users_logs`
--

CREATE TABLE `users_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL,
  `created_on` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_logs`
--

INSERT INTO `users_logs` (`id`, `users_id`, `created_on`, `data`, `ip_address`, `agent`) VALUES
(1, 1, 1564217491, '{\"controller\":\"admin\",\"item_id\":\"1\",\"method\":\"login\",\"message\":\"apx_admin login successful\"}', '27.75.141.51', 'Windows 10, Chrome, 75.0.3770.142'),
(2, 1, 1564225328, '{\"controller\":\"admin\",\"item_id\":\"1\",\"method\":\"login\",\"message\":\"apx_admin login successful\"}', '27.75.141.51', 'Windows 10, Chrome, 75.0.3770.142');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ci_sessions_id_uindex` (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `entities`
--
ALTER TABLE `entities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entities_recycles`
--
ALTER TABLE `entities_recycles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `languages_languages_supports_id_uindex` (`languages_supports_id`);

--
-- Indexes for table `languages_supports`
--
ALTER TABLE `languages_supports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `languages_supports_code_uindex` (`code`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages_layouts`
--
ALTER TABLE `pages_layouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `redirects`
--
ALTER TABLE `redirects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_slug_uindex` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_uindex` (`username`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_groups_name_uindex` (`name`);

--
-- Indexes for table `users_logs`
--
ALTER TABLE `users_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `entities`
--
ALTER TABLE `entities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `entities_recycles`
--
ALTER TABLE `entities_recycles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `languages_supports`
--
ALTER TABLE `languages_supports`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pages_layouts`
--
ALTER TABLE `pages_layouts`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `redirects`
--
ALTER TABLE `redirects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users_logs`
--
ALTER TABLE `users_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
